import asyncio
import sys
from urllib.parse import urlsplit
from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError
from aiogram.types import ErrorEvent, Update
from aiogram.dispatcher.middlewares.base import BaseMiddleware
import storage
from config import (
    ADMIN_TELEGRAM_IDS,
    BOT_TOKEN,
    BROADCAST_WEB_SECRET,
    PUBLIC_URL,
    TELEGRAM_AI_MEMORY_HOST,
    TELEGRAM_AI_MEMORY_PORT,
    TELEGRAM_AI_MEMORY_SECRET,
    TELEGRAM_BOT_API_URL,
)
from handlers import announcement as announcement_handler
from handlers import help as help_handler
from handlers import group as group_ai_handler
from handlers import qr as qr_handler
from handlers import start
from handlers import unblock as unblock_handler
from logger import logger
from handlers import web as web_handler
from telegram_retry import with_telegram_retry
from memory_server import start_server as start_telegram_ai_memory_server

CLEANUP_INTERVAL_SECONDS = 6 * 3600
TELEGRAM_REQUEST_TIMEOUT_SECONDS = 20


class TelegramUserRegistryMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: Update, data: dict):
        interaction = next(
            (
                getattr(event, name, None)
                for name in (
                    "message",
                    "edited_message",
                    "channel_post",
                    "edited_channel_post",
                    "business_message",
                    "edited_business_message",
                    "callback_query",
                    "inline_query",
                    "chosen_inline_result",
                    "shipping_query",
                    "pre_checkout_query",
                    "poll_answer",
                    "chat_member",
                    "my_chat_member",
                    "chat_join_request",
                )
                if getattr(event, name, None) is not None
            ),
            None,
        )
        user = getattr(interaction, "from_user", None)
        if user and not user.is_bot:
            try:
                await with_telegram_retry(
                    lambda: storage.record_telegram_bot_user_id(user.id),
                    label="user registry database write",
                    logger=logger,
                )
            except Exception as exc:
                logger.error(
                    f"Failed to record Telegram user ID {user.id}: {exc}"
                )
        return await handler(event, data)


def _verify_assets() -> bool:
    try:
        missing = [str(p) for p in qr_handler.required_assets() if not p.exists()]
    except Exception as exc:
        logger.error(f"Asset verification failed: {exc}")
        return False

    if missing:
        for path in missing:
            logger.warning(f"Missing asset: {path}")
        logger.warning("QR feature will report missing assets at runtime.")
        return False
    logger.info("QR assets verified.")
    return True


async def _verify_bot(bot: Bot) -> bool:
    try:
        me = await with_telegram_retry(
            bot.get_me,
            label="bot verification",
            logger=logger,
        )
        logger.info(f"Bot active: @{me.username} | {me.full_name} | ID: {me.id}")
        return True
    except TelegramAPIError as exc:
        logger.error(f"Bot verification failed: {exc}")
        return False
    except Exception as exc:
        logger.error(f"Unexpected error during bot verification: {exc}")
        return False


async def _cleanup_loop(bot: Bot) -> None:
    while True:
        try:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            removed = await storage.cleanup_expired(bot=bot)
            if removed:
                logger.info(f"Storage cleanup removed {removed} expired item(s)")
        except asyncio.CancelledError:
            return
        except Exception as exc:
            logger.error(f"Storage cleanup loop error: {exc}")


async def _run_cleanup_once(bot: Bot) -> None:
    try:
        removed = await storage.cleanup_expired(bot=bot)
        if removed:
            logger.info(f"Startup cleanup removed {removed} expired item(s)")
        else:
            logger.info("Startup cleanup: no expired media found.")
    except Exception as exc:
        logger.error(f"Startup cleanup failed: {exc}")


async def _run() -> int:
    if not BOT_TOKEN:
        logger.error("BOT_TOKEN not found. Please populate the .env file first.")
        return 1
    if TELEGRAM_BOT_API_URL:
        api_url = urlsplit(TELEGRAM_BOT_API_URL)
        if api_url.scheme not in {"http", "https"} or not api_url.netloc:
            logger.error(
                "TELEGRAM_BOT_API_URL must be an HTTP(S) base URL for a Local Bot API Server."
            )
            return 1

    try:
        session = (
            AiohttpSession(
                timeout=TELEGRAM_REQUEST_TIMEOUT_SECONDS,
                api=TelegramAPIServer.from_base(
                    TELEGRAM_BOT_API_URL,
                    is_local=True,
                ),
            )
            if TELEGRAM_BOT_API_URL
            else AiohttpSession(timeout=TELEGRAM_REQUEST_TIMEOUT_SECONDS)
        )
        bot = Bot(
            token=BOT_TOKEN,
            default=DefaultBotProperties(parse_mode=ParseMode.MARKDOWN_V2),
            session=session,
        )
    except Exception as exc:
        logger.error(f"Failed to initialize bot: {exc}")
        return 1
    if TELEGRAM_BOT_API_URL:
        logger.info(
            "Local Telegram Bot API configured; barcode uploads up to 50 MiB are available."
        )
    else:
        logger.warning(
            "Using Telegram's hosted Bot API. Media downloads above 20 MiB require "
            "a local Bot API server; the QR feature otherwise caps files at 20 MiB."
        )

    dp = Dispatcher()
    dp.update.outer_middleware(TelegramUserRegistryMiddleware())
    dp.include_router(announcement_handler.router)
    dp.include_router(start.router)
    dp.include_router(help_handler.router)
    dp.include_router(group_ai_handler.router)
    dp.include_router(unblock_handler.router)
    dp.include_router(qr_handler.router)
    dp.include_router(web_handler.router)

    @dp.errors()
    async def on_error(event: ErrorEvent) -> None:
        exc = event.exception
        logger.error(f"Unhandled error: {type(exc).__name__} - {exc}")
        update = event.update
        try:
            msg = getattr(update, "message", None)
            cbq = getattr(update, "callback_query", None)
            if msg is not None:
                await msg.answer(
                    "An internal error occurred, please try again later.",
                    parse_mode=None,
                )
            elif cbq is not None:
                await cbq.answer("An internal error occurred.", show_alert=True)
        except TelegramAPIError as tg_exc:
            logger.error(f"Failed to send error notification: {tg_exc}")
        except Exception as send_exc:
            logger.error(f"Error handler failed completely: {send_exc}")

    logger.info("CheyaVerse bot is starting...")

    _verify_assets()
    if not ADMIN_TELEGRAM_IDS:
        logger.warning("ADMIN_TELEGRAM_IDS is empty. /pesan broadcasts are disabled.")

    if not PUBLIC_URL:
        logger.warning("PUBLIC_URL is empty. QR media will use raw viewer paths.")
    else:
        logger.info(f"Public viewer base: {PUBLIC_URL}")
    if not BROADCAST_WEB_SECRET:
        logger.warning(
            "BROADCAST_WEB_SECRET is empty. Web announcement delivery is disabled."
        )

    try:
        await with_telegram_retry(
            storage.ensure_telegram_bot_user_ids_table,
            label="user registry database initialization",
            logger=logger,
        )
    except Exception as exc:
        logger.error(f"Telegram user registry initialization failed: {exc}")
        await bot.session.close()
        await storage.close_db_pool()
        return 1

    await _run_cleanup_once(bot)

    if not await _verify_bot(bot):
        logger.error("Bot failed to start. Check token and network connection.")
        try:
            await bot.session.close()
        except Exception:
            pass
        await storage.close_db_pool()
        return 1

    memory_runner: web.AppRunner | None = None
    if TELEGRAM_AI_MEMORY_SECRET:
        try:
            memory_runner = await start_telegram_ai_memory_server(
                TELEGRAM_AI_MEMORY_HOST,
                TELEGRAM_AI_MEMORY_PORT,
            )
            logger.info(
                "Telegram AI memory API listening on "
                f"{TELEGRAM_AI_MEMORY_HOST}:{TELEGRAM_AI_MEMORY_PORT}."
            )
        except Exception as exc:
            logger.error(f"Telegram AI memory API failed to start: {exc}")
            await bot.session.close()
            await storage.close_db_pool()
            return 1
    else:
        logger.warning(
            "Telegram AI memory API is disabled. Configure "
            "TELEGRAM_AI_MEMORY_SECRET before using local AI memory."
        )

    cleanup_task = asyncio.create_task(_cleanup_loop(bot))

    exit_code = 0
    try:
        await with_telegram_retry(
            lambda: bot.delete_webhook(drop_pending_updates=False),
            label="webhook cleanup",
            logger=logger,
        )
        logger.info("Polling engaged. Press CTRL+C to stop.")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except TelegramAPIError as exc:
        logger.error(f"Polling error: {exc}")
        exit_code = 1
    except Exception as exc:
        logger.error(f"Fatal error during polling: {exc}")
        exit_code = 1
    finally:
        cleanup_task.cancel()
        try:
            await cleanup_task
        except (asyncio.CancelledError, Exception):
            pass
        try:
            await bot.session.close()
        except Exception as exc:
            logger.error(f"Session cleanup failed: {exc}")
        try:
            await storage.close_db_pool()
        except Exception as exc:
            logger.error(f"Turso session cleanup failed: {exc}")
        if memory_runner is not None:
            try:
                await memory_runner.cleanup()
            except Exception as exc:
                logger.error(f"Telegram AI memory API shutdown failed: {exc}")
        logger.info("CheyaVerse bot has shut down.")

    return exit_code


def main() -> int:
    try:
        return asyncio.run(_run())
    except KeyboardInterrupt:
        logger.info("Manual shutdown (CTRL+C).")
        return 0
    except Exception as exc:
        logger.error(f"Crash at entry point: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
