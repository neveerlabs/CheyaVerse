import { redirect, notFound } from "next/navigation";

export const dynamic = "force-dynamic";

function isValidSegment(value: string): boolean {
  return /^[A-Za-z0-9_.-]{1,100}$/.test(value) && value !== "." && value !== "..";
}

export default function LegacyGitHubProjectPage({
  params,
}: {
  params: { uid: string; owner: string; repo: string };
}) {
  const uid = Number(params.uid);
  if (
    !Number.isSafeInteger(uid) ||
    uid <= 0 ||
    !isValidSegment(params.owner) ||
    !isValidSegment(params.repo)
  ) {
    notFound();
  }

  redirect(
    `/${uid}/project/${encodeURIComponent(params.owner)}/${encodeURIComponent(params.repo)}`,
  );
}
