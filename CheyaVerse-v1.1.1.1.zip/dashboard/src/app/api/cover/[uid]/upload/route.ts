import { NextRequest, NextResponse } from "next/server";
import { getCover, upsertCover } from "@/lib/storage";
import { broadcastToUid } from "@/lib/realtime";
import { getUserSession } from "@/lib/auth-request";
import {
  deleteUserMediaObject,
  isUserMediaPath,
  uploadUserMediaObject,
} from "@/lib/supabase-storage";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 5 * 1024 * 1024;

export async function POST(
  req: NextRequest,
  { params }: { params: { uid: string } },
) {
  const uid = Number(params.uid);
  if (!Number.isInteger(uid) || uid <= 0) {
    return NextResponse.json({ ok: false, error: "invalid_uid" }, { status: 400 });
  }
  if (!(await getUserSession(req, uid))) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  const form = await req.formData().catch(() => null);
  if (!form) {
    return NextResponse.json({ ok: false, error: "invalid_form" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof Blob)) {
    return NextResponse.json({ ok: false, error: "missing_file" }, { status: 400 });
  }

  const contentType = file.type || "image/jpeg";
  if (!contentType.startsWith("image/")) {
    return NextResponse.json({ ok: false, error: "only_images" }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ ok: false, error: "too_large" }, { status: 413 });
  }

  const filename =
    (form.get("filename") as string | null)?.slice(0, 120) ||
    `cover-${uid}-${Date.now()}.jpg`;

  let storagePath: string;
  try {
    storagePath = await uploadUserMediaObject(
      uid,
      "covers",
      file,
      filename,
      contentType,
    );
  } catch (error) {
    console.error("[cover/upload] Supabase Storage upload failed:", error);
    return NextResponse.json({ ok: false, error: "upload_failed" }, { status: 502 });
  }

  const prev = await getCover(uid);
  const res = await upsertCover(uid, {
    type: "upload",
    storage_path: storagePath,
    storage_message_id: null,
    content_type: contentType,
    color1: prev?.color1 ?? null,
    color2: prev?.color2 ?? null,
    icon: prev?.icon ?? null,
    bg_size: 100,
    bg_x: 50,
    bg_y: 50,
  });

  if (!res.ok) {
    await deleteUserMediaObject(uid, storagePath).catch((error) => {
      console.error("[cover/upload] Storage object rollback failed:", error);
    });
    return NextResponse.json({ ok: false, error: res.reason }, { status: 500 });
  }

  if (prev?.storage_path && isUserMediaPath(uid, prev.storage_path)) {
    await deleteUserMediaObject(uid, prev.storage_path).catch((error) => {
      console.error("[cover/upload] Previous cover cleanup failed:", error);
    });
  }
  const cover = await getCover(uid);
  await broadcastToUid(uid, { type: "cover:changed" });
  return NextResponse.json({ ok: true, cover });
}